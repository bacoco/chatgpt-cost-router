from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import subprocess

WORK = Path(__file__).parent
ROOT = WORK.parent / 'chatgpt-cost-router'
OUT = WORK / 'visual-tests' / '_results'
DELIVERY = WORK.parent / 'deliverables'
DELIVERY.mkdir(exist_ok=True)
structural = json.loads((OUT / 'structural-evidence.json').read_text())
run = json.loads((OUT / 'run.json').read_text())
SHA = structural['commit']
BASE = f'https://github.com/bacoco/chatgpt-cost-router/blob/{SHA}/'
NOW = datetime.datetime.now(datetime.timezone.utc).isoformat()


def ref(file, line, end=None):
    return {'file': file, 'line': line, 'end_line': end or line,
            'url': BASE + file + f'#L{line}' + (f'-L{end}' if end else '')}


def item(id, title, refs, description, example, fix, regression,
         kind='defect', severity='medium', evidence='reasoned', confidence='high'):
    return dict(id=id, title=title, refs=refs, description=description,
                counterexample=example, recommendation=fix, regression=regression,
                classification=kind, severity=severity, evidence=evidence,
                confidence=confidence)


items = [
    item('F01', 'Les deux skills ne respectent pas le format de métadonnées',
         [ref('skills/capability-router/SKILL.md', 1), ref('skills/surface-handoff/SKILL.md', 1)],
         'Les deux fichiers commencent par un titre Markdown et ne contiennent pas de frontmatter YAML avec name et description. Le validateur local officiel quick_validate.py renvoie pour chacun le code 1 et « No YAML frontmatter found ». Cela bloque leur conformité au format de skill natif. Leur lecture manuelle depuis GitHub reste possible.',
         'Valider séparément chacun des deux répertoires de skills avec quick_validate.py : les deux contrôles échouent avant toute invocation du skill.',
         'Ajouter les métadonnées aux deux skills, définir leurs conditions de déclenchement et documenter la méthode d’installation ou de chargement depuis GitHub.',
         'Les deux validations de format passent; vérifier ensuite séparément découverte et invocation sur la surface cible. Un format valide ne démontre pas que le skill a été exécuté.',
         evidence='measured'),
    item('F02', 'Le producteur de handoff peut omettre la version exigée par le schéma',
         [ref('skills/surface-handoff/SKILL.md', 3, 6), ref('schemas/handoff.schema.json', 5, 7), ref('docs/HANDOFF_SPEC.md', 5)],
         'Le skill énumère les informations à produire mais omet version et ne renvoie ni au schéma ni à un exemple canonique. Le schéma impose version=1. L’exemple documentaire contient bien la version, ce qui ne corrige pas le contrat du skill chargé seul.',
         'Un producteur fournit tous les champs demandés par le skill, avec recommended_surface, remaining et success_criteria, mais sans version : la condition required du schéma est violée. Il ne s’agit pas d’une sortie LLM effectivement observée.',
         'Faire du schéma une référence explicite du skill, fournir un exemple valide et exiger sa validation avant remise du handoff.',
         'Un paquet sans version est rejeté; le paquet canonique généré selon le skill est accepté; une version inconnue est traitée explicitement.',
         kind='contract-conflict'),
    item('F03', 'Le schéma laisse les champs de contexte et de contrôle sans validation',
         [ref('schemas/handoff.schema.json', 5, 14), ref('docs/HANDOFF_SPEC.md', 6, 18), ref('skills/surface-handoff/SKILL.md', 4)],
         'Sept champs de l’exemple ne sont pas déclarés dans properties : task_id, from_surface, repo, files, constraints, tests et return_to_chat_when. Le skill demande aussi une branche et une raison d’escalade sans définir leurs clés JSON. Ces champs peuvent être absents ou porter n’importe quel type. Aucun autre contrat ou validateur n’existe dans les 13 fichiers suivis. Le schéma ne prouve donc pas la conservation des contraintes et des informations nécessaires à la reprise.',
         'Ajouter à un paquet minimal par ailleurs conforme : {"repo":[],"constraints":null,"tests":42,"return_to_chat_when":false}. Ces valeurs ne sont soumises à aucune contrainte par le schéma actuel. Une faute de frappe dans un de ces champs facultatifs n’est pas détectée non plus.',
         'Déclarer et typer tous les champs connus; définir lesquels sont obligatoires selon le sens du transfert et la tâche. Décider séparément si les extensions inconnues restent autorisées. Ne pas simplement ajouter additionalProperties:false avant d’avoir déclaré les champs de l’exemple.',
         'Tester les mauvais types et l’omission des champs indispensables; l’exemple complet doit continuer à être accepté. Tester les différences entre transfert vers un spécialiste et retour après achèvement.',
         kind='contract-conflict'),
    item('F04', 'Un handoff sans objectif ni critère de réussite satisfait le schéma',
         [ref('schemas/handoff.schema.json', 9, 13), ref('skills/capability-router/SKILL.md', 3), ref('SPEC.md', 7)],
         'goal est seulement une chaîne; success_criteria est seulement un tableau de chaînes. Aucun minimum ni contrôle de contenu non blanc n’est prévu. Le contrat de structure accepte donc un paquet inutilisable pour définir ou vérifier la mission.',
         '{"version":1,"goal":"","recommended_surface":"CODEX","remaining":[],"success_criteria":[]} satisfait les contraintes déclarées. Des chaînes constituées uniquement d’espaces restent également possibles. Attention : remaining=[] est légitime lors d’un retour de tâche terminée; ce n’est pas, à lui seul, un défaut.',
         'Exiger un objectif non blanc et des critères de réussite exploitables, avec règles adaptées aux handoffs terminaux. Les seules contraintes de longueur ne suffisent pas pour rejeter les espaces.',
         'Rejeter objectif vide ou blanc et critères absents de sens; conserver un retour valide avec remaining=[] et des preuves d’achèvement.'),
    item('F05', 'Le vocabulaire des routes et les routes composites ne sont pas stabilisés',
         [ref('SPEC.md', 10), ref('schemas/handoff.schema.json', 8), ref('skills/capability-router/SKILL.md', 8), ref('docs/ARCHITECTURE.md', 11), ref('tests/routing_cases.md', 8, 12)],
         'Le contrat machine utilise LOCAL_TOOL alors que le skill et l’architecture utilisent LOCAL/MCP. HYBRID est autorisé par le schéma mais ne possède ni règle de sélection ni structure décrivant ses composants. Les fixtures comportent aussi un transport, une composition et un choix entre plusieurs surfaces. Les abréviations de prose ne démontrent pas une erreur de sérialisation déjà produite; elles signalent un contrat encore incomplet.',
         'Si LOCAL/MCP est sérialisé tel quel dans recommended_surface, il est hors enum. À l’inverse, HYBRID est dans enum mais ne dit pas si le travail doit être planifié, calculé localement, ni dans quel ordre. La fixture « MCP + SCHEDULED_CHAT » n’apporte pas ce modèle.',
         'Utiliser un vocabulaire canonique unique et documenter les alias de présentation. Soit définir HYBRID avec étapes, ordonnanceur, exécutants et dépendances, soit le retirer tant qu’il n’est pas pris en charge.',
         'Chaque route de sortie et chaque fixture se normalise sans ambiguïté; un plan hybride contient assez d’information pour être exécuté.',
         kind='specification-gap'),
    item('F06', 'Les dix fixtures ne permettent pas de mesurer un accord de routage reproductible',
         [ref('tests/routing_cases.md', 3, 12), ref('SPEC.md', 25), ref('skills/capability-router/SKILL.md', 20)],
         'Chaque fixture contient une tâche et une préférence de surface, mais aucune photographie des capacités, autorisations, contraintes utilisateur ou conditions de disponibilité. Les cas 6, 8 et 10 mêlent route, moyen de transport, composition et alternatives. Ces dix lignes sont des exemples humains, pas des tests exécutés ni un oracle suffisamment défini pour calculer le >90% annoncé.',
         'La fixture 2 attend CHAT pour créer une issue. Une session Chat sans outil GitHub de création, ou sans autorisation d’écriture, ne peut satisfaire ce résultat tout en respectant l’obligation de preuve runtime. Les conditions permettant de distinguer les deux situations ne sont pas dans la fixture.',
         'Transformer les cas en données structurées : tâche, surface courante, capacités vérifiées et leurs portées, restrictions, sorties acceptées, motif et plan. Ajouter les variantes outil absent, lecture seule, authentification expirée et instruction de ne pas escalader.',
         'Deux évaluateurs recevant la même politique et les mêmes capacités obtiennent une attente comparable. Le taux d’accord doit indiquer le dénominateur et les cas exclus.',
         kind='specification-gap'),
    item('F07', 'Les observations de capacités ne sont pas reliées à leurs preuves',
         [ref('docs/ARCHITECTURE.md', 23, 26), ref('README.md', 100), ref('schemas/handoff.schema.json', 12)],
         'La liste PASS / NOT EXPOSED / FAIL ne donne ni date, environnement, surface confirmée, compte ou portée de connexion, étapes du test, ni référence vers le résultat. Aucun procès-verbal de ces audits n’est présent parmi les fichiers suivis. Le README demande correctement une revérification runtime : le défaut est la traçabilité des observations historiques, pas une instruction de les croire universelles.',
         'Une nouvelle session lit « GitHub read/write PASS » : ce document ne permet pas de savoir quelle action, quel dépôt et quel environnement ont réellement été vérifiés.',
         'Joindre un manifeste de capacités daté, contextualisé et sourcé; séparer visible, invocable et exécuté; conserver un état unknown quand la preuve manque.',
         'Une observation sans provenance ne devient pas une capacité acquise; un résultat sur un dépôt ou une session ne vaut pas pour un autre.',
         kind='specification-gap', severity='low'),
]

risks = [
    item('D01', 'La priorité fixe ne démontre pas le coût minimal',
         [ref('skills/capability-router/SKILL.md', 3, 19), ref('README.md', 175, 176), ref('docs/TOKEN_ECONOMICS.md', 10, 17)],
         'Le coût n’a ni unité, ni formule, ni poids relatif pour les quotas, le temps, les appels, les retries, CI, transfert et calcul local. La liste de préférence peut être une heuristique, mais ne suffit pas à prouver une minimisation. Réduire Work/Codex peut déplacer la dépense vers une API ou de la CI.',
         'Scénario hypothétique : deux routes sont suffisantes, mais le transfert et les relances de la première dépassent le coût restant sur la surface courante. Aucun calcul ne permet de les départager.',
         'Définir le coût réellement optimisé et les contraintes de qualité/délai; traiter la préférence comme un départage après filtrage des capacités et estimation du coût marginal.',
         'Comparer des routes suffisantes de coûts inversés et une estimation de coût inconnue.', kind='design-question', severity='low'),
    item('D02', 'Le précontrôle doit vérifier une action et sa portée, pas seulement un nom d’outil',
         [ref('skills/capability-router/SKILL.md', 20), ref('README.md', 100), ref('docs/ROADMAP.md', 9, 10)],
         'Le préflight est explicitement prévu pour une phase ultérieure. Il reste à distinguer outil visible, connexion authentifiée, action autorisée, action réellement réussie, fraîcheur et surface cible. Une preuve de lecture ne prouve pas l’écriture; un outil dans Work ne prouve pas sa présence dans Chat.',
         'Lecture d’un dépôt réussie mais création de branche interdite; outil media visible mais Spark éteint; connexion valide dans la session courante mais absente chez le destinataire.',
         'Définir un manifeste par session, ressource et action, les états verified / unavailable / unknown et une stratégie de sondes sans effet de bord. Rafraîchir au transfert et après un échec.',
         'Tests de lecture seule, permission partielle, expiration, machine hors ligne et absence de preuve côté destinataire.', kind='design-question'),
    item('D03', 'Le retour vers Chat doit dépendre de la tâche restante et du coût du transfert',
         [ref('skills/capability-router/SKILL.md', 21), ref('docs/ROUTING_SPEC.md', 24, 25), ref('README.md', 141), ref('docs/HANDOFF_SPEC.md', 18, 22)],
         'Le retour est formulé comme un réflexe. La règle générale de suffisance peut empêcher un mauvais retour, mais ni préflight explicite de destination, ni gain minimal, ni traitement d’une ré-escalade ne sont décrits.',
         'L’implémentation est finie dans Codex; la revue restante nécessite un dépôt privé inaccessible depuis Chat. Un retour non conditionnel entraîne un blocage ou un aller-retour supplémentaire. C’est un scénario, pas une boucle mesurée.',
         'Réévaluer seulement le travail restant, vérifier les capacités de destination et ne transférer que si cela apporte un bénéfice. Conserver l’historique et une limite raisonnée aux bascules.',
         'Destination incapable, tâche presque terminée, nouvelle erreur CI et absence de progrès après plusieurs transferts.', kind='design-question', severity='low'),
    item('D04', 'Aucun résultat de routage bloqué n’est défini',
         [ref('SPEC.md', 10), ref('schemas/handoff.schema.json', 5, 8), ref('skills/capability-router/SKILL.md', 3, 21)],
         'Toutes les sorties documentées désignent une route. Le résultat attendu quand aucune route n’est suffisante, autorisée ou démontrée n’est pas défini. Ce statut devrait appartenir à la décision de routage, sans nécessairement devenir une surface de handoff.',
         'Aucun outil d’édition disponible et utilisateur interdisant Work, Codex et l’API : le routeur doit pouvoir expliquer son blocage sans inventer une capacité.',
         'Définir un statut blocked / needs-input avec cause, travail déjà accompli et plus petite information ou connexion nécessaire.',
         'Aucune route disponible, routes disponibles mais interdites, coût inconnu sous plafond strict.', kind='design-question'),
    item('D05', 'Une recommandation de surface n’est pas un transfert confirmé',
         [ref('docs/HANDOFF_SPEC.md', 3, 22), ref('docs/MCP_PLAN.md', 3, 17), ref('README.md', 230, 257)],
         'Le paquet indique recommended_surface; aucun protocole de remise, d’accusé de réception, de statut distant, de résultat ou d’annulation n’est défini. Le dépôt ne fournit aucun adaptateur lançant une surface. Il ne faut donc pas annoncer un transfert automatique effectif à partir de ce seul JSON.',
         'Un handoff CODEX est produit, mais aucun destinataire ne le reçoit; ou submit_job répond de façon incertaine avant que l’orchestrateur ne sache si le travail a commencé.',
         'Distinguer recommandé, remis, accepté, en cours, terminé et échec. Définir un adaptateur par destination et une remise manuelle explicite lorsqu’aucun lancement automatique n’est disponible.',
         'Destination indisponible, réponse perdue, reprise par un humain, annulation et résultat tardif.', kind='design-question'),
    item('D06', 'La reprise et les preuves doivent être rattachées à un état exact',
         [ref('docs/HANDOFF_SPEC.md', 6, 18), ref('docs/HANDOFF_SPEC.md', 22), ref('README.md', 251, 255), ref('SPEC.md', 14, 18)],
         '« Vérifier l’état courant » est demandé, mais aucune règle ne lie tâche, branche, commit, artefact, preuve de test et version de politique. Un repo et un nom de fichier ne suffisent pas à reconstruire l’état analysé. Ce problème subsiste même si les champs de F03 sont correctement typés.',
         'Un résultat CI concerne le commit A, puis la branche avance à B avant réception; ou le skill chargé depuis main change entre deux exécutions de la même tâche.',
         'Référencer task/run/parent IDs, commit SHA, branche lorsque pertinente, preuves accessibles, politique/version de skill et état attendu. Prévoir le traitement d’un état devenu obsolète.',
         'Branche avancée, résultat d’un autre commit, référence inaccessible et changement de politique entre deux runs.', kind='design-question'),
    item('D07', 'Les effets distants et la concurrence du scheduler restent à contractualiser',
         [ref('docs/ROADMAP.md', 9, 10), ref('README.md', 292, 313), ref('docs/MCP_PLAN.md', 5, 13), ref('docs/MCP_PLAN.md', 21, 22)],
         'L’idempotence, les chevauchements, le checkpoint T-1, les retries et les limites d’autorisation entre surfaces ne sont pas définis. Les allowlists, secrets côté serveur, limites et journaux sont déjà prévus pour universal-api-mcp; il faut les transformer en critères applicables à chaque exécuteur. Aucun contournement de sécurité en fonctionnement n’a été démontré.',
         'Une newsletter a été envoyée mais le checkpoint n’est pas enregistré; un retry peut renvoyer. Deux tâches quotidiennes se chevauchent. Une autorisation de revue ne doit pas devenir une autorisation de déploiement lors d’un handoff.',
         'Définir clés d’idempotence, limites de concurrence, ordre effet/checkpoint et reprise sur résultat incertain. Transmettre explicitement les contraintes utilisateur, permissions et plafonds; réévaluer l’autorisation au point d’effet.',
         'Double livraison, échec après effet réussi, run tardif, chevauchement et tâche lecture seule reçue par une surface dotée de pouvoirs d’écriture.', kind='design-question'),
    item('D08', 'Les objectifs économiques ne disposent pas encore d’un protocole de mesure',
         [ref('SPEC.md', 22, 27), ref('docs/TOKEN_ECONOMICS.md', 3, 17), ref('docs/ROADMAP.md', 3, 4), ref('docs/ROADMAP.md', 24, 25)],
         'Les chiffres sont explicitement des hypothèses, ce qui est correct. Il manque toutefois l’unité d’usage, le périmètre du coût, la période de référence, la normalisation par charge et qualité, et le classement des tâches inachevées ou déplacées vers une API. La mesure est listée en fin de roadmap; la baseline réelle doit être prise avant les changements.',
         'Un mois avec moitié moins de tâches affiche une baisse Work/Codex de 50% sans gain du routeur; une réduction de tâches terminées peut aussi faire baisser artificiellement la consommation.',
         'Mesurer une baseline dès le départ, comparer des tâches similaires réussies, publier coûts déplacés, délais et qualité, puis les gains de quota et de monnaie séparément.',
         'Charge variable, tâches échouées, transfert de coûts CI/API, cache différent et changement de politique.', kind='design-question', severity='low'),
]

simplifications = [
    ('Les pseudo-agents planifiés pour un besoin de vrais sous-agents',
     [ref('docs/USE_CASES.md', 23), ref('tests/routing_cases.md', 12)],
     'Le tableau met des pseudo-agent schedulers en face de « True subagents », alors que la fixture exige trois agents synchrones et isolés. Séparer les travaux indépendants asynchrones du besoin de délégation synchrone; ne pas présenter l’un comme équivalent à l’autre.'),
    ('La récurrence, la surface et le calcul local dans une seule liste',
     [ref('SPEC.md', 10), ref('skills/capability-router/SKILL.md', 5, 11), ref('tests/routing_cases.md', 10)],
     'Une tâche peut être déclenchée par le scheduler, orchestrée dans Chat et exécutée sur Spark via MCP. Décrire un plan composé avec déclencheur, orchestrateur, exécuteur et transport est plus précis que multiplier des surfaces mutuellement exclusives.'),
    ('Le nombre de fichiers comme indicateur principal de difficulté',
     [ref('docs/USE_CASES.md', 9, 10), ref('tests/routing_cases.md', 5, 6)],
     'Conserver 4/20/120 fichiers comme exemples. Une correction sur un fichier peut nécessiter une intégration lourde; 120 modifications mécaniques peuvent être simples. Décider surtout avec les outils requis, la boucle de validation, les dépendances et les limites de contexte.'),
    ('Les cinq passerelles avant la preuve de valeur du routeur',
     [ref('docs/MCP_PLAN.md', 3, 22), ref('docs/ROADMAP.md', 15, 22)],
     'Prioriser un contrat de décision, un handoff valide, des fixtures contextualisées et un seul parcours mesuré. Reporter les passerelles spécialisées sans besoin démontré évite de transformer un outil d’économie en une grande plateforme d’orchestration.'),
    ('Les règles dupliquées dans README, spécifications, skills et fixtures',
     [ref('README.md', 164, 199), ref('docs/ROUTING_SPEC.md', 1, 25), ref('skills/capability-router/SKILL.md', 1, 21)],
     'Définir une politique canonique versionnée et faire pointer les autres documents dessus. Le README dit au présent que le skill exécute cinq étapes, tandis qu’il annonce aussi un moteur futur; préciser ce qui existe comme instruction et ce qui reste à développer.'),
]

fixture_reviews = [
    ('1', 'Papier arXiv + Loriq', 'CHAT', 'Recherche/lecture du papier et accès au dépôt vérifiés; volume compatible avec la session.'),
    ('2', 'Créer une issue', 'CHAT', 'Action de création d’issue disponible, bonne portée de dépôt et autorisation utilisateur.'),
    ('3', 'Quatre fichiers + PR + CI', 'CHAT', 'Écriture/branche/PR et récupération du résultat CI sur le bon commit disponibles.'),
    ('4', '120 fichiers + tests locaux répétés', 'CODEX', 'Environnement et outils de test disponibles; la nécessité vient de la boucle de travail, pas seulement du nombre.'),
    ('5', 'Veille quotidienne Spark', 'SCHEDULED_CHAT', 'Création de tâche, sources nécessaires et exécution future compatibles avec les outils autorisés.'),
    ('6', 'ComfyUI sur Sparky', 'LOCAL_TOOL via media-mcp', 'Passerelle effectivement installée et machine disponible; séparer route et nom du transport.'),
    ('7', 'Administration uniquement via UI', 'WORK', 'Navigateur adapté à la cible, accès authentifié et autorisation de l’action.'),
    ('8', 'API privée horaire + delta', 'MCP + SCHEDULED_CHAT', 'Plan composite explicite, authentification, stockage du point T-1 et règles de reprise.'),
    ('9', 'Revue Codex + notes de version', 'CHAT', 'Résultat et preuves accessibles dans Chat; transfert utile compte tenu du travail restant.'),
    ('10', 'Trois agents synchrones et isolés', 'WORK/CODEX/SDK si nécessaire', 'Une route choisie avec preuve de véritable délégation synchrone; un scheduler de pseudo-agents ne suffit pas.'),
]

counterexamples = [
    ('C01', 'Skill sans métadonnées', 'Échec de quick_validate sur les deux skills.', 'measured', 'F01'),
    ('C02', 'Tous les champs demandés par le skill, sans version', 'Non conforme à required; sortie LLM non exécutée.', 'reasoned', 'F02'),
    ('C03', 'repo=[], constraints=null, tests=42', 'Aucune contrainte appliquée à ces champs inconnus du schéma.', 'reasoned', 'F03'),
    ('C04', 'Objectif vide + critères vides', 'Compatible avec les seules contraintes actuelles.', 'reasoned', 'F04'),
    ('C05', 'Objectif constitué d’espaces', 'Compatible avec type:string; pas de règle de contenu.', 'reasoned', 'F04'),
    ('C06', 'Retour terminé avec remaining=[]', 'Cas légitime à conserver; pas un bug.', 'reasoned', 'F04'),
    ('C07', 'Route sérialisée LOCAL/MCP', 'Hors enum; aucun appel réel d’un moteur ne l’a produite.', 'reasoned', 'F05'),
    ('C08', 'Route HYBRID sans étapes', 'Enum satisfaite mais exécution sous-définie.', 'reasoned', 'F05'),
    ('C09', 'Créer une issue sans outil d’écriture', 'L’oracle CHAT ne précise pas comment traiter ce contexte.', 'reasoned', 'F06'),
    ('C10', 'Capacité historique dans une nouvelle session', 'Le PASS historique ne prouve pas la disponibilité courante.', 'reasoned', 'F07'),
    ('C11', 'Deux routes suffisantes avec coûts inversés', 'Priorité heuristique sans arbitrage de coût défini.', 'reasoned', 'D01'),
    ('C12', 'Outil visible mais permission lecture seule', 'Disponibilité apparente insuffisante pour conclure à l’écriture.', 'reasoned', 'D02'),
    ('C13', 'Retour vers Chat sans accès au dépôt', 'Besoin de préflight de destination et de décision de rester.', 'reasoned', 'D03'),
    ('C14', 'Toutes les routes indisponibles ou interdites', 'Résultat blocked à définir.', 'reasoned', 'D04'),
    ('C15', 'Handoff recommandé mais jamais accepté', 'Ne peut pas être assimilé à un transfert accompli.', 'reasoned', 'D05'),
    ('C16', 'Résultat CI de A, branche devenue B', 'Preuve à rattacher au SHA vérifié.', 'reasoned', 'D06'),
    ('C17', 'Effet réussi puis checkpoint échoué', 'Politique anti-duplication et reprise à définir.', 'reasoned', 'D07'),
    ('C18', 'Autorisation de revue reçue par un exécuteur de déploiement', 'Les capacités ne doivent pas étendre l’autorisation utilisateur.', 'reasoned', 'D07'),
    ('C19', 'Baisse de charge indépendante du routeur', 'Une baisse de consommation brute ne prouve pas une économie du routage.', 'reasoned', 'D08'),
]


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')


save('review-data.json', {'repo': 'bacoco/chatgpt-cost-router', 'commit': SHA,
                        'findings': items, 'design_questions': risks,
                        'simplifications': simplifications,
                        'fixture_reviews': fixture_reviews, 'counterexamples': counterexamples})

# Native ShipGuard result layout, with explicit degradation for this repository.
# No zero-bug application audit or runtime pass is asserted.
run['timestamp'] = NOW
run['lanes']['audit'] = {'status': 'not-applicable', 'reason': 'No executable application source or infrastructure in the tracked repository; format and schema review reported in the Logic lane.'}
run['lanes']['logic'] = {'status': 'ran', 'results': 'logic-results.json'}
run['adaptation'] = 'Documented routing procedure, instruction contracts and JSON Schema analyzed. Skill format validation measured. No router execution, no fabricated runtime baseline.'
save('run.json', run)

candidates = [
    {'id': 'p01', 'kind': 'procedure', 'name': 'Chargement des skills',
     'files': ['skills/capability-router/SKILL.md', 'skills/surface-handoff/SKILL.md'],
     'model': {'inputs': ['SKILL.md'], 'states': ['document', 'format-checked'], 'effects': ['none: read-only format validation']},
     'obligations': [{'id': 'o01', 'statement': 'Un skill natif comporte un frontmatter name/description.',
                      'source': {'file': 'https://learn.chatgpt.com/docs/build-skills', 'line': 840},
                      'source_kind': 'declared', 'confidence': 'high'}], 'findings': []},
    {'id': 'p02', 'kind': 'procedure', 'name': 'Production et réception du handoff',
     'files': ['skills/surface-handoff/SKILL.md', 'schemas/handoff.schema.json', 'docs/HANDOFF_SPEC.md'],
     'model': {'inputs': ['task, context, evidence'], 'states': ['prepared', 'received'], 'effects': ['proposed transfer; no implementation exists']},
     'obligations': [{'id': 'o02', 'statement': 'Un handoff doit transmettre un objectif et des critères permettant de vérifier la tâche.',
                      'source': {'file': 'skills/surface-handoff/SKILL.md', 'line': 4}, 'source_kind': 'declared', 'confidence': 'high'}], 'findings': []},
    {'id': 'p03', 'kind': 'algorithm', 'name': 'Choix de route et évaluation',
     'files': [x['path'] for x in structural['files'] if x['path'] not in ['skills/surface-handoff/SKILL.md', 'schemas/handoff.schema.json', 'docs/HANDOFF_SPEC.md']],
     'model': {'inputs': ['task, current surface, capabilities, constraints'], 'states': ['classify', 'preflight', 'score', 'route', 're-evaluate'], 'effects': ['policy recommendation; no executable router']},
     'obligations': [{'id': 'o03', 'statement': 'Choisir une capacité suffisante avec preuve runtime et évaluer les décisions sur des fixtures canoniques.',
                      'source': {'file': 'SPEC.md', 'line': 13}, 'source_kind': 'declared', 'confidence': 'high'}], 'findings': []},
]
for data, candidate, oid in [(items[0], candidates[0], 'o01'), (items[3], candidates[1], 'o02')]:
    candidate['findings'].append({'id': data['id'], 'title': data['title'], 'kind': 'postcondition-violation',
                                 'severity': data['severity'], 'status': 'confirmed', 'obligation_id': oid,
                                 'evidence': data['evidence'], 'confidence': data['confidence'],
                                 'assumptions': ['Native skill loading is the applicability scope. Manual GitHub reading is still possible.'] if data['id'] == 'F01' else ['The schema is intended to validate a useful handoff; no receiving runtime was executed.'],
                                 'counterexample': data['counterexample'],
                                 'trace': [data['description'], data['recommendation']],
                                 'file': data['refs'][0]['file'], 'line': data['refs'][0]['line'],
                                 'related_audit_bug_id': None})


def concern(data, candidate):
    return {'id': data['id'], 'title': data['title'], 'description': data['title'] + ' — ' + data['description'],
            'candidate_id': candidate, 'sources': data['refs'], 'file': data['refs'][0]['file'],
            'line': data['refs'][0]['line'], 'evidence': data['evidence'], 'severity': data['severity'],
            'counterexample': data['counterexample'], 'recommendation': data['recommendation']}


uncovered = [
    {'description': 'No executable router, cost scorer or route adapter; no production behavior or cost measured.', 'candidate_id': 'p03', 'sources': [ref('README.md', 186), ref('README.md', 381, 388)]},
    {'description': 'No standards-compliant JSON Schema validator available in the inspected runtimes. JSON parsing and structural facts measured; acceptance examples reasoned from the schema and normative specification.', 'candidate_id': 'p02', 'sources': [ref('schemas/handoff.schema.json', 1, 15)]},
    {'description': 'No skill invocation evaluation; quick_validate checks file format only.', 'candidate_id': 'p01', 'sources': [ref('skills/capability-router/SKILL.md', 1)]},
    {'description': 'No live Chat, Scheduler, hardware, gateway, paid-provider or CI execution performed.', 'candidate_id': 'p03', 'sources': [ref('docs/MCP_PLAN.md', 1, 22)]},
]
logic = {'schema_version': '1.0', 'repo': 'bacoco/chatgpt-cost-router', 'timestamp': NOW,
         'scope': {'type': 'full', 'value': SHA, 'files': [f['path'] for f in structural['files']]},
         'mode': 'hybrid', 'depth': 'standard', 'status': 'partial',
         'summary': {'candidates_checked': 3, 'obligations_checked': 3, 'confirmed_violations': 2,
                     'risks': 0, 'contract_conflicts': 3, 'questions': 10, 'uncovered': len(uncovered),
                     'by_severity': {'critical': 0, 'high': 0, 'medium': 2, 'low': 0},
                     'evidence_mix': {'reasoned': 1, 'measured': 1}},
         'candidates': candidates,
         'contract_conflicts': [concern(items[1], 'p02'), concern(items[2], 'p02'), concern(items[4], 'p03')],
         'questions': [concern(i, 'p03') for i in items[5:] + risks],
         'uncovered': uncovered, 'skipped': [], 'impacted_backend': [], 'impacted_ui_routes': [],
         'notes': 'Two grouped violations + three contract conflicts + two documented evaluation/evidence gaps = seven current findings. Eight additional design questions. Runtime coverage remains unavailable. The measured finding contains two failed skill-format checks.'}
save('logic-results.json', logic)
save('process-results.json', {'repo': 'bacoco/chatgpt-cost-router', 'timestamp': NOW, 'mode': 'reason',
     'base_ref': None, 'head_ref': SHA, 'summary': {'units_checked': 0, 'behavior_changes': 0, 'new_errors': 0,
     'surprises': 0, 'evidence_mix': {'reasoned': 0, 'measured': 0}, 'by_verdict': {}},
     'units': [], 'impacted_backend': [], 'impacted_ui_routes': [],
     'skipped': [{'file': '*', 'reason': run['lanes']['process']['reason']}],
     'uncovered': ['Executable router and before/after runtime behavior.'], 'status': 'not-applicable'})
(OUT / 'process-report.md').write_text('Process check non applicable : revue du dépôt complet à un commit fixé, sans moteur exécutable ni comportement avant/après à mesurer. Les scénarios sont une analyse des contrats, pas une simulation mesurée du routeur.\n')

def links(refs):
    return ', '.join(f"[{r['file']}:{r['line']}" + (f"–{r['end_line']}" if r['end_line'] != r['line'] else '') + f"]({r['url']})" for r in refs)


lines = [
    '# Audit de chatgpt-cost-router', '',
    f'**Dépôt examiné :** [bacoco/chatgpt-cost-router](https://github.com/bacoco/chatgpt-cost-router/tree/{SHA}) — branche `main`, commit `{SHA}` (4 septembre 2026). Revue réalisée le 5 septembre 2026.', '',
    '**Conclusion : le dépôt constitue un début de spécification, pas encore un routeur opérationnel.** Les 13 fichiers suivis ont été lus intégralement : 638 lignes logiques, 12 fichiers Markdown et un schéma JSON. Il contient deux skills de 21 et 6 lignes, dix fixtures en prose, aucune application exécutable, aucun serveur MCP, aucun test automatisé ou workflow CI. L’absence du moteur est explicitement annoncée dans la roadmap; elle n’est pas comptée comme un bug caché.', '',
    '**Résultat : 4 défauts de format ou de contrat (F01–F04), 3 lacunes documentées de routage/évaluation/preuve (F05–F07), puis 8 questions de conception avant implémentation (D01–D08).** Les six premiers constats sont de priorité P2 et F07 de priorité P3. Aucun incident critique, crash, fuite de données ou contournement de sécurité en fonctionnement n’a été établi.', '',
    '**Méthode et portée.** Skill ShipGuard `sg-ship` trouvé dans une copie locale du dépôt ShipGuard, puis application de ses principes : périmètre figé, contrats explicites, contre-exemples, séparation du mesuré et du raisonné, relecture indépendante et rapport unifié. Une seconde revue a lu les 13 fichiers et tenté de réfuter les constats. Adaptation nécessaire : les contrôles applicatifs, avant/après et visuels sont non applicables à ce dépôt. Le tableau de bord n’équivaut pas à un passage end-to-end de ShipGuard sur une application.', '',
    '| Vérification | Résultat effectivement établi |',
    '|---|---|',
    '| Accès GitHub + clone de main | Même SHA, arborescence récursive complète; tous les fichiers suivis lus |',
    '| Validateur de skills officiel local | 2 contrôles exécutés, 2 échecs : `No YAML frontmatter found` |',
    '| Schéma JSON | JSON parsé; propriétés, champs requis et exemple comparés par script |',
    '| Validation normative de paquets JSON | Raisonnée à partir du schéma; `jsonschema` et AJV indisponibles, aucun moteur de remplacement improvisé |',
    '| Fixtures | 10 cas lus et confrontés aux prérequis; aucun test du routeur exécuté |',
    '| Scénarios adverses | 19 scénarios recensés; 1 scénario de format mesuré (2 fichiers), 18 raisonnés |',
    '| Application, UI, coûts réels, passerelles | Non testés : aucune implémentation dans le périmètre |',
    '| Modifications du dépôt distant et des sources | Aucune; aucune issue, PR ou correction publiée |', '',
    '**Constats prioritaires**', '',
    '| ID | Priorité | Constat | Nature de la preuve |',
    '|---|---|---|---|',
]
for d in items:
    lines.append(f"| {d['id']} | {'P3' if d['severity']=='low' else 'P2'} | {d['title']} | {'Validation de format mesurée' if d['evidence']=='measured' else 'Lecture complète et contre-exemple raisonné'} |")

for d in items:
    lines += ['', f"**{d['id']} — {d['title']}**", '', links(d['refs']), '', d['description'], '',
              '**Contre-exemple / preuve :** ' + d['counterexample'], '',
              '**Correction proposée :** ' + d['recommendation'], '',
              '**Vérification après correction :** ' + d['regression']]

lines += ['', '**Portée de la validation du schéma**', '',
          'Les comportements de F02–F05 découlent des règles JSON Schema; ce rapport ne les présente pas comme des sorties d’un validateur exécuté. La spécification autorise les propriétés supplémentaires en l’absence de restriction et n’impose pas une présence ou un minimum de contenu implicite. [Objets et propriétés supplémentaires](https://json-schema.org/understanding-json-schema/reference/object), [vocabulaire de validation 2020-12](https://json-schema.org/draft/2020-12/json-schema-validation).', '',
          'Le défaut de métadonnées F01 est corroboré par le format officiel : `name` et `description` dans le frontmatter, puis les instructions. [Construire des skills](https://learn.chatgpt.com/docs/build-skills), [erreurs de soumission des skills](https://developers.openai.com/plugins/deploy/submission-errors). Aucune installation native ni invocation des deux skills du dépôt n’a été tentée.', '',
          '**Questions de conception et risques avant implémentation**', '',
          'Ces points ne sont pas des vulnérabilités ou des erreurs runtime observées. Le dépôt annonce déjà comme futurs le moteur, le préflight, les hooks et les passerelles. Les scénarios ci-dessous servent à préciser leurs critères d’acceptation. Les priorités D ne sont pas additionnées au nombre de bugs.', '']
for d in risks:
    lines += [f"**{d['id']} — {d['title']}**", '', links(d['refs']), '', d['description'], '',
              '**Cas à traiter :** ' + d['counterexample'], '', '**Décision proposée :** ' + d['recommendation'], '',
              '**Cas de vérification :** ' + d['regression'], '']

lines += ['**Logiques à simplifier ou à rendre plus précises**', '']
for title, refs, text in simplifications:
    lines += [f'**{title}.** {text} ' + links(refs), '']

lines += ['**Relecture des dix fixtures existantes**', '',
          'Il s’agit de conditions nécessaires et de décisions à formaliser, pas de résultats PASS/FAIL d’un moteur.', '',
          '| Cas | Demande | Attente écrite dans le dépôt | Prérequis ou précision nécessaire |',
          '|---|---|---|---|']
for row in fixture_reviews:
    lines.append('| ' + ' | '.join(row) + ' |')
lines += ['', '**Contre-exemples et limites contrôlés**', '',
          '| ID | Cas | Observation ou conclusion bornée | Preuve | Constat |',
          '|---|---|---|---|---|']
for row in counterexamples:
    lines.append('| ' + ' | '.join(row) + ' |')

lines += ['', '**Ce qu’il ne faut pas qualifier de bug**', '',
          '- Le moteur, les hooks et les passerelles sont encore à développer : la roadmap le dit explicitement.',
          '- Les économies de 50–80 % et le gain de contexte de 20–50 % sont déclarés comme des hypothèses; aucune économie réelle n’est démontrée, mais le dépôt ne les présente pas comme une garantie de facturation.',
          '- Le dépôt explique correctement que faire appeler Codex/Claude par MCP ne rend pas leur usage gratuit.',
          '- Un handoff de retour peut avoir `remaining=[]`. Le rejeter systématiquement casserait un cas utile.',
          '- Le budget « typical handoff <5 KB » est un objectif statistique, pas une limite de validité universelle. Un hard cap nécessite une décision et une stratégie de références vers les détails.',
          '- Les propriétés JSON supplémentaires peuvent servir à l’extensibilité. Le défaut actuel est surtout l’absence de déclaration des champs connus, pas l’absence universellement fautive de `additionalProperties:false`.',
          '- Les phrases des fixtures ne sont pas la preuve qu’un moteur les sérialise telles quelles.',
          '- Aucun code mort, SQL, autorisation contournée, retry effectivement dupliqué ou boucle infinie en fonctionnement ne peut être affirmé sans l’implémentation correspondante.', '',
          '**Ordre de correction conseillé**', '',
          '1. Corriger le format des deux skills et aligner le producteur de handoff sur un exemple et un schéma canoniques.',
          '2. Déclarer les champs de handoff et les invariants minimaux; fixer les routes et le traitement de HYBRID.',
          '3. Formaliser un résultat de décision avec capacités prouvées, restrictions, motif, état bloqué et plan de transfert.',
          '4. Convertir les dix fixtures en cas contextualisés; ajouter les cas de refus, destination indisponible et preuve périmée.',
          '5. Mesurer une baseline et implémenter un premier parcours complet, puis seulement les passerelles dont la valeur est établie.', '',
          '**Couverture fichier par fichier**', '',
          '| Fichier | Lignes logiques lues | Revue |',
          '|---|---:|---|']
for f in structural['files']:
    affected = [x['id'] for x in items + risks if any(r['file']==f['path'] for r in x['refs'])]
    lines.append(f"| [{f['path']}]({BASE+f['path']}) | {f['lines']} | Lu intégralement; " + (', '.join(affected) if affected else 'pas de constat indépendant supplémentaire') + ' |')
lines += ['', '**Traçabilité de l’audit**', '',
          f'Le dossier de preuves contient l’inventaire et les empreintes de chaque fichier, les recherches d’absence sur tout le périmètre, les résultats des deux validations, les contre-exemples, les données de revue et les fichiers ShipGuard. Le SHA de référence est `{SHA}`. Le comptage de 638 utilise les lignes logiques de `splitlines()`; `wc -l` compte 637 sauts de ligne car le README n’a pas de saut de ligne final.', '',
          'Le rapport couvre intégralement les fichiers présents à ce commit, mais ne constitue ni une preuve formelle d’absence d’autres défauts, ni une vérification des capacités actuelles de toutes les surfaces ChatGPT. Les hypothèses d’environnement et les comportements futurs restent explicitement séparés des faits mesurés.', '']
report = '\n'.join(lines)
(OUT / 'logic-report.md').write_text(report)
md_path = DELIVERY / 'chatgpt-cost-router-audit.md'
md_path.write_text(report)

# Keep the independent-review record compact and exact; no invented numeric scores.
save('independent-verification.json', {
    'reviewer': '/root/verify_contracts', 'commit': SHA, 'files_read': 13,
    'result': 'All 13 files independently reviewed. No critical/high runtime issue established.',
    'agreed_findings': [d['id'] for d in items],
    'cautions_applied': ['Do not reject every empty remaining array.',
                         'Do not claim fixture transport prose was emitted verbatim.',
                         'Do not count explicitly planned runtime components as hidden bugs.',
                         'Do not equate fixed priorities with a proven cost failure.',
                         'Schema examples are reasoned, not executed with a standards validator.',
                         'Manual GitHub reading of the skills remains possible.']})

# Ensure repository sources are exactly the audited state.
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
assert not status, status
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SHA
for data in items + risks:
    for r in data['refs']:
        count = len((ROOT / r['file']).read_text().splitlines())
        assert 1 <= r['line'] <= r['end_line'] <= count, r
save('final-checks.json', {'commit': SHA, 'source_worktree_clean': True,
     'references_within_files': True, 'current_findings': len(items),
     'format_or_contract_defects': 4, 'additional_specification_gaps': 3,
     'design_questions': len(risks), 'existing_fixtures_reviewed': len(fixture_reviews),
     'counterexample_scenarios': len(counterexamples),
     'runtime_router_tests_executed': 0, 'skill_format_checks_executed': 2,
     'skill_format_checks_failed': 2})
print(json.dumps({'report': str(md_path), 'findings': len(items), 'design_questions': len(risks),
                  'source_worktree_clean': True}, ensure_ascii=False))
