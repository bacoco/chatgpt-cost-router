from pathlib import Path
from html.parser import HTMLParser
import json
import urllib.request
import subprocess
import shutil
import zipfile
import time

base = Path(__file__).parent.parent
w = base / 'audit-work'
r = w / 'visual-tests/_results'
d = base / 'deliverables'
# This audit-generated PID file belongs to an earlier isolated command. Do not
# ask the review builder to signal its numeric PID in a different namespace.
(r / '.server.pid').unlink(missing_ok=True)
server = subprocess.Popen(['node', str(w / 'visual-tests/build-review.mjs'), '--serve', '--port=8898'],
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
try:
    for _ in range(40):
        try:
            with urllib.request.urlopen('http://127.0.0.1:8898/health', timeout=1) as response:
                health = json.load(response)
            break
        except OSError:
            time.sleep(.1)
    else:
        raise RuntimeError('Review server unavailable')
    print('health:', json.dumps(health))
    with urllib.request.urlopen('http://127.0.0.1:8898', timeout=2) as response:
        raw = response.read().decode()
finally:
    server.terminate()
    log = server.communicate(timeout=5)[0]
    (r / '.server.pid').unlink(missing_ok=True)
print(log[-450:])


class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.inside = False
        self.items = []

    def handle_starttag(self, tag, attrs):
        if tag == 'script':
            self.inside = True
            self.items.append('')

    def handle_endtag(self, tag):
        if tag == 'script':
            self.inside = False

    def handle_data(self, data):
        if self.inside:
            self.items[-1] += data


p = Scripts()
p.feed(raw)
for i, script in enumerate(p.items):
    if script.strip():
        f = w / f'temporary-js-check-{i}.js'
        f.write_text(script)
        checked = subprocess.run(['node', '--check', str(f)], capture_output=True, text=True)
        assert checked.returncode == 0, checked.stderr
        f.unlink()
assert '__PLACEHOLDER_' not in raw
for ident in [f'F{i:02}' for i in range(1, 8)] + [f'D{i:02}' for i in range(1, 9)]:
    assert ident in raw, ident
for fpath in r.glob('*.json'):
    json.loads(fpath.read_text())
shutil.copyfile(r / 'review.html', d / 'chatgpt-cost-router-shipguard.html')
checks = json.loads((r / 'final-checks.json').read_text())
checks.update({'dashboard_http_health': True, 'dashboard_inline_js_syntax': True,
               'all_15_ids_embedded': True, 'dashboard_url_during_check': 'http://127.0.0.1:8898',
               'review_server_stopped_after_check': True, 'all_json_files_parse': True})
(r / 'final-checks.json').write_text(json.dumps(checks, indent=2, ensure_ascii=False) + '\n')
readme = '''Audit bacoco/chatgpt-cost-router — ca763e51842cb1b53452fb41464232600572c6cd

Ouvrir chatgpt-cost-router-audit.md pour le rapport complet.
Ouvrir audit-work/visual-tests/_results/review.html pour le tableau ShipGuard embarqué.
La page distingue deux violations, trois conflits et dix questions (deux lacunes
actuelles + huit questions de conception). Ce sont sept constats actuels, pas
quinze bugs runtime. Les deux erreurs de format de skills sont regroupées en F01.

Pour utiliser les fonctions de serveur du tableau avec Node.js :
node audit-work/visual-tests/build-review.mjs --serve --port=8898
URL locale affichée et vérifiée durant la revue : http://127.0.0.1:8898
Le serveur de vérification a été arrêté; les données embarquées restent consultables.
Arrêt : node audit-work/visual-tests/build-review.mjs --stop

Le générateur build_audit.py est conservé pour la traçabilité. Il attend un clone
chatgpt-cost-router au même niveau que audit-work, figé au SHA ci-dessus, ainsi que
les preuves préexistantes incluses. Il ne corrige pas les sources.
La copie du moteur de tableau ShipGuard est incluse pour pouvoir rouvrir la revue.

Aucun test d'application ou de surface distante n'a été exécuté. Les exemples
JSON Schema sont raisonnés; seuls les deux contrôles de format et les vérifications
structurelles décrites dans les preuves sont mesurés.
'''
zip_path = d / 'chatgpt-cost-router-audit-evidence.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(d / 'chatgpt-cost-router-audit.md', 'chatgpt-cost-router-audit.md')
    z.writestr('README.txt', readme)
    for path in sorted(w.rglob('*')):
        if path.is_file() and not path.name.startswith('.') and '__pycache__' not in path.parts:
            z.write(path, str(path.relative_to(base)))
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
print('artifacts:', json.dumps([{'name': f.name, 'bytes': f.stat().st_size} for f in
      [d / 'chatgpt-cost-router-audit.md', d / 'chatgpt-cost-router-shipguard.html', zip_path]], ensure_ascii=False))
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=base / 'chatgpt-cost-router', text=True)
print('repository unchanged')
