Audit bacoco/chatgpt-cost-router — ca763e51842cb1b53452fb41464232600572c6cd

Ouvrir chatgpt-cost-router-audit.md pour le rapport complet.
Ouvrir audit-work/visual-tests/_results/review.html pour le tableau ShipGuard embarqué.
La page distingue deux violations, trois conflits et dix questions (deux lacunes
actuelles + huit questions de conception). Ce sont sept constats actuels, pas
quinze bugs runtime. Les deux erreurs de format de skills sont regroupées en F01.

Pour utiliser les fonctions de serveur du tableau avec Node.js :
node audit-work/visual-tests/build-review.mjs --serve --port=8898
URL locale affichée et vérifiée durant la revue : http://127.0.0.1:8898
Le serveur de vérification a été arrêté; les données embarquées restent consultables.
Arrêt : node audit-work/visual-tests/build-review.mjs --stop

Le générateur build_audit.py est conservé pour la traçabilité. Il attend un clone
chatgpt-cost-router au même niveau que audit-work, figé au SHA ci-dessus, ainsi que
les preuves préexistantes incluses. Il ne corrige pas les sources.
La copie du moteur de tableau ShipGuard est incluse pour pouvoir rouvrir la revue.

Aucun test d'application ou de surface distante n'a été exécuté. Les exemples
JSON Schema sont raisonnés; seuls les deux contrôles de format et les vérifications
structurelles décrites dans les preuves sont mesurés.
